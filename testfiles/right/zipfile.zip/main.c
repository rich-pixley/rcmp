/*
 * Copyright © 2013 K Richard Pixley
 */

#include <stdio.h>

int main(int argc, char **argv) {
	return 0;
}
